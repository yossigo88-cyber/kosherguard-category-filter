// Category-only adapter for the existing dashboard's data-site-category controls.
// No device, enrollment, profile, push or traffic interfaces.
export async function mountCategoryControls(root,{base='/api/category-filter',onStatus=()=>{}}={}){
 let ownerVersion=null,busy=false;
 const controls=()=>[...root.querySelectorAll('[data-site-category]')];
 async function refresh(){controls().forEach(x=>x.disabled=true);const r=await fetch(base+'/status');if(!r.ok)throw Error('Category settings unavailable');const data=await r.json();ownerVersion=data.selection_version;controls().forEach(x=>{x.checked=data.settings[x.dataset.siteCategory]===true;x.disabled=false});for(const c of data.categories){const input=controls().find(x=>x.dataset.siteCategory===c.id);if(!input)continue;let note=root.querySelector('[data-coverage-category="'+c.id+'"]');if(!note){note=document.createElement('small');note.dataset.coverageCategory=c.id;note.style.cssText='display:block;font-size:12px;line-height:1.4;color:#666;margin:4px 12px 12px';input.closest('label')?.after(note)}note.textContent=c.id==='malware'&&data.threat_evidence_expired?c.count.toLocaleString()+' stored hosts · 0 current · expired, unresolved':c.count?c.count.toLocaleString()+' mapped hosts · limited coverage · exact match':'0 mapped hosts · empty coverage · needs evidence'}onStatus(data);return data}
 for(const input of controls())input.addEventListener('change',async()=>{
  if(busy||ownerVersion===null)return;busy=true;controls().forEach(x=>x.disabled=true);
  try{const r=await fetch(base+'/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({category:input.dataset.siteCategory,blocked:input.checked,expected_version:ownerVersion})});if(!r.ok)throw Error('Category setting not saved');await refresh()}catch(e){try{await refresh()}catch{};onStatus({error:e.message})}finally{busy=false}
 });
 await refresh();return {refresh};
}
