import {mountCategoryControls} from '/existing-dashboard-adapter.js';mountCategoryControls(document).then(()=>document.body.dataset.ready='true').catch(e=>document.body.dataset.error=e.message);
