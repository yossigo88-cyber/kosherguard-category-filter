"""Atomic offline runtime replacement, preserving correction/settings overlay."""
from pathlib import Path
import sqlite3,hashlib,json,os,shutil
from runtime import ROOT

def install(candidate,target,state,expected_sha256):
 candidate=Path(candidate);target=Path(target);state=Path(state)
 digest=hashlib.sha256(candidate.read_bytes()).hexdigest()
 if digest!=expected_sha256:raise ValueError('candidate checksum mismatch')
 d=sqlite3.connect('file:'+str(candidate.resolve())+'?mode=ro',uri=True)
 if d.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('candidate integrity failure')
 meta=dict(d.execute('SELECT key,value FROM metadata'));count=d.execute('SELECT count(*) FROM categories').fetchone()[0];d.close()
 expected=hashlib.sha256((ROOT/'docs/policy-v1.0.json').read_bytes()).hexdigest()
 if count!=28 or meta.get('policy_hash')!=expected or meta.get('enforcement')!='DISABLED' or meta.get('scope')!='EXACT_HOST':raise ValueError('candidate policy/scope/disabled-enforcement mismatch')
 # Existing state must already be well formed and is never rewritten by feed updates.
 before=state.read_bytes();x=json.loads(before)
 if not isinstance(x.get('corrections'),list) or not isinstance(x.get('settings'),dict):raise ValueError('invalid existing state')
 stage=target.with_suffix('.next.sqlite');backup=target.with_suffix('.previous.sqlite');shutil.copyfile(candidate,stage)
 with stage.open('rb') as f:os.fsync(f.fileno())
 if target.exists():shutil.copyfile(target,backup)
 os.replace(stage,target)
 assert state.read_bytes()==before
 return dict(installed_sha256=digest,previous_retained=backup.exists(),state_unchanged=True,enforcement=False)
