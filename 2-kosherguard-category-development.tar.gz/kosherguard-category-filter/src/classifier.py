import ipaddress,unicodedata,re
import idna
class ReviewRequired(ValueError):pass
def normalize(value):
    if not isinstance(value,str) or not value or value!=value.strip(): raise ValueError('invalid host')
    if any(c in value for c in '/:@?#*\\%') or any(c.isspace() for c in value): raise ValueError('host only, no wildcard/URL/port/encoding')
    if value.endswith('.'): value=value[:-1]
    if not value or value.endswith('.'): raise ValueError('ambiguous trailing dots')
    try:
        ipaddress.ip_address(value)
    except ValueError: pass
    else: raise ValueError('IP literals require a separate, unsupported policy')
    value=unicodedata.normalize('NFC',value.lower())
    try: result=idna.encode(value,uts46=False,std3_rules=True).decode('ascii')
    except idna.IDNAError as e: raise ValueError('invalid IDNA') from e
    if len(result)>253 or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',x) for x in result.split('.')): raise ValueError('invalid DNS labels')
    if all(x.isdigit() for x in result.split('.')): raise ValueError('ambiguous numeric host')
    return result


def matches(target, host, scope):
    return target==host or (scope==DESC and target.endswith('.'+host))


