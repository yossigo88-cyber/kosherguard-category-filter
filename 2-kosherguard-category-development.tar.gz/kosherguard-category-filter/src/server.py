"""Category-only staging HTTP adapter. Loopback only, no device/MDM APIs."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import json,threading,os,hashlib,tempfile,time,uuid,sys
from runtime import ROOT,Runtime,IDS,POLICY,BITS,normalize,ReviewRequired
LOCK=threading.RLock()
class State:
 def __init__(self,path):
  self.path=Path(path)
  if not self.path.exists():self.write({'version':1,'selection_version':0,'settings':{k:False for k in IDS},'corrections':[],'audit':[],'metadata':{'environment':'staging'}})
 def read(self):return json.loads(self.path.read_text())
 def write(self,x):
  self.path.parent.mkdir(parents=True,exist_ok=True);tmp=self.path.with_suffix('.tmp');
  with tmp.open('w') as f:json.dump(x,f,indent=2);f.flush();os.fsync(f.fileno())
  os.replace(tmp,self.path)
 def update(self,key,value,expected_version=None):
  with LOCK:
   s=self.read()
   if key not in IDS or type(value) is not bool:raise ValueError('known category and boolean required')
   # A partial legacy record is never completed with invented OFF values.
   if set(s['settings'])!=set(IDS):raise ReviewRequired('legacy settings incomplete; supply explicit full migration')
   if expected_version is not None and expected_version!=s['selection_version']:raise ReviewRequired('settings changed in another session, refresh first')
   s['settings'][key]=value;s['selection_version']+=1;s['audit'].append(dict(action='selection',category=key,blocked=value,version=s['selection_version']));self.write(s);return s
 def correct(self,host,category,scope='EXACT_HOST'):
  if category not in IDS or scope not in ('EXACT_HOST','HOST_AND_DESCENDANTS'):raise ValueError('invalid correction category/scope')
  h=normalize(host)
  # Use frozen real PSL validator, prevents suffix-wide corrections.
  from feed_validation import PSL
  PSL(ROOT/'evidence/public_suffix_list.dat').validate(h)
  with LOCK:
   s=self.read();c=dict(id=uuid.uuid4().hex,host=h,category=category,scope=scope,kind='SUPPRESS',policy='1.0');s['corrections'].append(c);s['audit'].append(dict(action='correction',id=c['id']));self.write(s);return c

 def revoke(self,correction_id):
  with LOCK:
   s=self.read();matches=[c for c in s['corrections'] if c['id']==correction_id and c['kind']=='SUPPRESS']
   if not matches or any(c.get('supersedes')==correction_id for c in s['corrections']):raise ValueError('unknown or already revoked correction')
   c=dict(id=uuid.uuid4().hex,kind='REVOKE',supersedes=correction_id,policy='1.0');s['corrections'].append(c);s['audit'].append(dict(action='revoke',id=c['id'],supersedes=correction_id));self.write(s);return c

class App:
 def __init__(self,db,state):self.db=Path(db);self.state=State(state);self.local=threading.local()
 def lookup(self,host):
  s=self.state.read();signature=(self.db.stat().st_ino,self.db.stat().st_mtime_ns,json.dumps(s['corrections'],sort_keys=True))
  if getattr(self.local,'signature',None)!=signature:
   if getattr(self.local,'runtime',None):self.local.runtime.close()
   self.local.runtime=Runtime(self.db,s['corrections']);self.local.signature=signature
  return self.local.runtime.classify(host,s['settings'],s['selection_version'])
 def status(self):
  s=self.state.read();r=Runtime(self.db,s['corrections']);counts={x['category']:x['count'] for x in json.loads((ROOT/'artifacts/runtime-manifest.json').read_text())['counts']};meta=r.meta;r.close()
  counts=json.loads(meta.get('category_counts',json.dumps(counts)))
  return dict(settings=s['settings'],selection_version=s['selection_version'],corrections=s['corrections'],categories=[dict(c,count=counts[c['id']]) for c in POLICY['categories']],database_bytes=self.db.stat().st_size,metadata=meta,threat_evidence_expired=time.time()>=float(meta.get('threat_expires','0')),enforcement=False,environment='LOCAL_STAGING',production_connected=False)

def handler(app):
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*a):pass
  def reply(self,status,obj):
   b=json.dumps(obj).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
  def do_GET(self):
   if self.path=='/api/category-filter/status':return self.reply(200,app.status())
   if self.path=='/health':return self.reply(200,dict(ok=True,enforcement=False))
   files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/before':'before.html','/categories':'existing.html','/compat-init.js':'compat-init.js','/existing-dashboard-adapter.js':'existing-dashboard-adapter.js'}
   if self.path not in files:return self.reply(404,dict(error='Not found; no device or MDM routes exist'))
   p=ROOT/'public'/files[self.path];b=p.read_bytes();self.send_response(200);self.send_header('Content-Type','text/html' if p.suffix=='.html' else 'text/javascript' if p.suffix=='.js' else 'text/css');self.send_header('Content-Length',str(len(b)));self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'");self.end_headers();self.wfile.write(b)
  def do_POST(self):
   origin=self.headers.get('Origin')
   if origin and origin!='http://'+self.headers.get('Host',''):return self.reply(403,dict(error='Cross-origin request rejected'))
   if self.headers.get('Content-Type')!='application/json':return self.reply(415,dict(error='JSON required'))
   try:
    size=int(self.headers.get('Content-Length','0'))
    if size>16384:return self.reply(413,dict(error='Body too large'))
    body=json.loads(self.rfile.read(size))
    if self.path=='/api/category-filter/settings':
     app.state.update(body['category'],body['blocked'],body.get('expected_version'));return self.reply(200,app.status())
    if self.path=='/api/category-filter/classify':return self.reply(200,app.lookup(body['host']))
    if self.path=='/api/category-filter/corrections/revoke':return self.reply(200,app.state.revoke(body['id']))
    if self.path=='/api/category-filter/corrections':return self.reply(200,app.state.correct(body['host'],body['category'],body.get('scope','EXACT_HOST')))
    return self.reply(404,dict(error='No device, MDM or activation APIs'))
   except ReviewRequired as e:return self.reply(409,dict(error=str(e),status='REVIEW_REQUIRED',safe=False,traffic_action='NONE'))
   except (ValueError,KeyError) as e:return self.reply(400,dict(error=str(e),safe=False,traffic_action='NONE'))
   except Exception:return self.reply(503,dict(status='UNAVAILABLE',safe=False,traffic_action='NONE',error='Lookup unavailable; no allow/block outage decision applied'))
 return Handler

def serve(db=None,state=None,port=8766):
 app=App(db or ROOT/'artifacts/runtime.sqlite',state or ROOT/'artifacts/staging-settings.json');server=ThreadingHTTPServer(('127.0.0.1',port),handler(app));server.serve_forever()
if __name__=='__main__':serve(port=int(os.environ.get('PORT','8766')),state=os.environ.get('STAGING_STATE'))
