"""Explicit one-shot evidence refresh; no scheduler, never contacts listed hosts."""
from pathlib import Path
import urllib.request,datetime,json,hashlib,sqlite3,os
from runtime import ROOT,normalize

def refresh():
 url='https://hole.cert.pl/domains/v2/domains.json'
 with urllib.request.urlopen(url,timeout=30) as r:
  if r.status!=200 or 'json' not in r.headers.get('Content-Type',''):raise ValueError('unexpected CERT response')
  data=r.read(100*1024*1024)
  if len(data)>=100*1024*1024:raise ValueError('source too large')
  headers=dict(r.headers)
 rows=json.loads(data)
 if not isinstance(rows,list) or len(rows)<100:raise ValueError('unexpected empty/invalid threat snapshot')
 staging=Path(os.environ.get('KOSHERGUARD_STAGING_SOURCE','/tmp/kosherguard-checkpoint-b'))
 db=sqlite3.connect('file:'+str(staging/'artifacts/kosherguard-ut1-staging.sqlite')+'?mode=ro',uri=True)
 hosts={r[0] for r in db.execute("SELECT DISTINCT h.host FROM source_assertions a JOIN hostname_rules h ON h.id=a.rule WHERE a.category='malware'")};db.close()
 confirmed=[]
 for r in rows:
  host=r.get('DomainAddress');inserted=datetime.datetime.fromisoformat(r['InsertDate']);now=datetime.datetime.now(datetime.timezone.utc)
  if r.get('DeleteDate') or not host or host not in hosts:continue
  if inserted>now or (now-inserted).days>184:continue
  if normalize(host)!=host:continue
  confirmed.append(r)
 fetched=datetime.datetime.now(datetime.timezone.utc).isoformat();digest=hashlib.sha256(data).hexdigest();archive=ROOT/'evidence/history'/digest;archive.mkdir(parents=True,exist_ok=True)
 (archive/'cert-active.json').write_bytes(data)
 meta=dict(url=url,bytes=len(data),sha256=digest,fetched_at=fetched,headers=headers,intersected_ut1_hosts=len(confirmed))
 (archive/'download.json').write_text(json.dumps(meta,indent=2))
 # These evidence working files are inputs only. Runtime replacement remains an explicit separate operation.
 (ROOT/'evidence/cert-active.json').write_bytes(data);(ROOT/'evidence/cert-download.json').write_text(json.dumps(meta,indent=2));(ROOT/'evidence/cert-ut1-intersection.json').write_text(json.dumps(confirmed,indent=2));print(json.dumps(meta,indent=2))
if __name__=='__main__':refresh()
