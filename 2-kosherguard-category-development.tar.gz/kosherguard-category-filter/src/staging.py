"""Offline UT1 staging. No production, network, settings or device adapters."""
from pathlib import Path
import sys, hashlib, json, re, sqlite3, unicodedata
sys.path.insert(0,str(Path(__file__).parent))
from classifier import normalize, Classifier, ReviewRequired

ROOT=Path(__file__).resolve().parents[1]
class PSL:
    def __init__(self,path=ROOT/'originals/public_suffix_list.dat'):
        data=Path(path).read_bytes();self.version='psl-sha256:'+hashlib.sha256(data).hexdigest()
        self.rules=set(); self.exceptions=set()
        for line in data.decode().splitlines():
            line=line.strip()
            if not line or line.startswith('//'):continue
            if line.startswith('!'):self.exceptions.add(self.ascii(line[1:]))
            else:self.rules.add(self.ascii(line))
    @staticmethod
    def ascii(s):return '.'.join(x.encode('idna').decode('ascii') if x!='*' else '*' for x in s.split('.'))
    def suffix(self,host):
        labels=host.split('.'); best=labels[-1]
        for i in range(len(labels)):
            tail='.'.join(labels[i:])
            if tail in self.exceptions:return '.'.join(labels[i+1:])
            if tail in self.rules:best=tail;break
            if i+1<len(labels) and '*.'+'.'.join(labels[i+1:]) in self.rules:best=tail;break
        return best
    def validate(self,host):
        if '.' not in host or self.suffix(host)==host:raise ValueError('public/private suffix or single-label host')

def normalize_feed(raw,psl):
    s=raw.decode('utf-8',errors='strict').strip()
    if not s or s.startswith('#'):return None,'blank/comment'
    # Outer whitespace and ASCII case are harmless feed transformations; no URL/port stripping.
    h=normalize(s)
    psl.validate(h)
    if h.endswith(('.invalid','.test','.example','.localhost')) or h in ('localhost','invalid','test','example'):raise ValueError('reserved test namespace')
    return h,None

class StagingStore:
    def __init__(self,path):
        path=Path(path).resolve()
        if ROOT/'artifacts' not in path.parents:raise ValueError('staging artifacts path required')
        self.db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
        self.db.row_factory=sqlite3.Row;self.db.execute('PRAGMA query_only=ON');self.db.execute('PRAGMA cache_size=-8192')
        self.psl=PSL()
    def correction_version(self):return self.db.execute('SELECT count(*) FROM review_decisions').fetchone()[0]
    def close(self):self.db.close()

class CandidateClassifier:
    """Review aid only. Candidate evidence never masquerades as an approved classification."""
    def __init__(self,store):self.store=store
    def inspect(self,target,settings):
        h=normalize(target);self.store.psl.validate(h)
        ids={r[0] for r in self.store.db.execute('SELECT id FROM categories')}
        if set(settings)!=ids or any(type(v) is not bool for v in settings.values()):raise ReviewRequired('complete explicit selections required')
        rows=self.store.db.execute('SELECT a.category,m.source_category,m.disposition,m.reason,a.id FROM hostname_rules h JOIN source_assertions a ON a.rule=h.id JOIN staging_assertion_sources s ON s.assertion=a.id JOIN mapping_plan m ON m.source_category=s.source_category AND m.category=a.category WHERE h.host=? AND h.scope=\'EXACT_HOST\' ORDER BY a.category,m.source_category',(h,)).fetchall()
        cats=sorted({r['category'] for r in rows});eligible=sorted({r['category'] for r in rows if r['disposition']=='PROVISIONAL'})
        return dict(host=h,status='CANDIDATE_ONLY' if rows else 'UNKNOWN',candidate_categories=cats,provisional_categories=eligible,hypothetical_enabled_candidates=sorted(c for c in eligible if settings[c]),evidence=[dict(r) for r in rows],enforcement=False,approved=False)
