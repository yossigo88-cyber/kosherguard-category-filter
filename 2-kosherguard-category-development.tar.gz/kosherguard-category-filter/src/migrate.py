"""Offline import of a category-settings record. Never reads live devices."""
from pathlib import Path
import json,os,hashlib
from runtime import IDS,ReviewRequired

def migrate_record(record,destination,corrections=None):
 # Caller supplies an explicit, already-owned configuration record. Missing flags require review.
 if not isinstance(record,dict):raise ValueError('object required')
 saved=record.get('siteCategorySettings',record.get('settings'))
 if not isinstance(saved,dict) or set(saved)!=set(IDS) or any(type(x) is not bool for x in saved.values()):raise ReviewRequired('All 28 existing flags must be explicit booleans. Do not default absent legacy values OFF.')
 original=json.dumps(record,sort_keys=True);dest=Path(destination)
 if dest.exists():raise ValueError('Refuse overwrite of existing state')
 state=dict(version=1,selection_version=0,settings=dict(saved),corrections=list(corrections if corrections is not None else record.get('corrections',[])),audit=[dict(action='offline_migration',source_hash=hashlib.sha256(original.encode()).hexdigest())],metadata=dict(environment='staging',original_fields=record))
 tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2));os.replace(tmp,dest)
 assert json.dumps(record,sort_keys=True)==original
 return state
