"""Build compact runtime only from preserved evidence, no crawling or network."""
from pathlib import Path
import sqlite3,json,hashlib,time,os,sys,datetime
from runtime import ROOT,IDS,BITS
STAGING=Path(os.environ.get('KOSHERGUARD_STAGING_SOURCE','/tmp/kosherguard-checkpoint-b'))
def build(destination=None):
 target=Path(destination or ROOT/'artifacts/runtime.sqlite');tmp=target.with_suffix('.building.sqlite')
 if tmp.exists():tmp.unlink()
 source=sqlite3.connect('file:'+str(STAGING/'artifacts/kosherguard-ut1-staging.sqlite')+'?mode=ro',uri=True)
 d=sqlite3.connect(tmp);d.executescript('''PRAGMA page_size=4096; PRAGMA journal_mode=DELETE; CREATE TABLE hosts(host TEXT PRIMARY KEY,mask INTEGER NOT NULL,threat_expires INTEGER NOT NULL DEFAULT 0) WITHOUT ROWID; CREATE TABLE categories(id TEXT PRIMARY KEY,ordinal INTEGER UNIQUE NOT NULL,name TEXT NOT NULL,definition TEXT NOT NULL,inclusions TEXT NOT NULL,exclusions TEXT NOT NULL,rules TEXT NOT NULL) WITHOUT ROWID; CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL) WITHOUT ROWID; CREATE TABLE evidence(id TEXT PRIMARY KEY,host TEXT NOT NULL,category TEXT NOT NULL,source_url TEXT NOT NULL,reason TEXT NOT NULL,checked_at TEXT NOT NULL,expires INTEGER NOT NULL DEFAULT 0) WITHOUT ROWID;''')
 p=json.loads((ROOT/'docs/policy-v1.0.json').read_text())
 for c in p['categories']:d.execute('INSERT INTO categories VALUES (?,?,?,?,?,?,?)',(c['id'],c['n'],c['name'],c['definition'],c['yes'],c['no'],c['rules']))
 def put(host,cat,expires=0):
  d.execute('INSERT INTO hosts VALUES (?,?,?) ON CONFLICT(host) DO UPDATE SET mask=mask|excluded.mask,threat_expires=max(threat_expires,excluded.threat_expires)',(host,BITS[cat],expires))
 for host,cat in source.execute('SELECT h.host,e.category FROM effective_assignments e JOIN hostname_rules h ON h.id=e.rule'):put(host,cat)
 # Only reviewed exact hostnames. A domain name or an adult list label alone is insufficient.
 reviewed=[dict(host='pornhub.com',category='adult',url='https://help.pornhub.lifestyle/hc/en-us/articles/4419885579795-Parental-Controls',reason='First-party platform policy explicitly describes access to sexually explicit content; independent UT1 Adult membership; excludes non-explicit/educational inference.'),dict(host='ome.tv',category='anonymous',url='https://ome.tv/',reason='First-party describes random stranger webcam matching as central service.'),dict(host='ome.tv',category='messaging',url='https://ome.tv/',reason='First-party describes substantial real-time video conversations.'),dict(host='ome.tv',category='social',url='https://ome.tv/',reason='First-party describes separate photo profiles/followers social network.'),dict(host='torproject.org',category='browsers',url='https://www.torproject.org/',reason='First-party Tor Browser distribution/support is a central service.'),dict(host='torproject.org',category='bypass',url='https://www.torproject.org/',reason='First-party describes routing access to websites blocked by local network.'),dict(host='bittorrent.com',category='piracy',url='https://www.bittorrent.com/',reason='Dedicated torrent-client distribution expressly included by frozen policy, not a claim of piracy or illegality.')]
 reviewed.extend([
  dict(host='chatgpt.com',category='ai',url='https://chatgpt.com/',reason='First-party interactive AI interface; exact UT1 AI host, not entire cloud provider.'),
  dict(host='dropbox.com',category='cloud',url='https://www.dropbox.com/',reason='First-party core cloud storage and file-sharing services; exact UT1 host, no tenant/CDN inheritance.'),
  dict(host='youtube.com',category='video',url='https://support.google.com/youtube/answer/57407?hl=en',reason='First-party upload-video instructions and platform documentation establish substantial prerecorded video service; exact UT1 audio-video host.'),
  dict(host='elementvape.com',category='drugs',url='https://www.elementvape.com/',reason='First-party primary retail catalog explicitly sells vaping devices and e-liquid, not health education; supplemental reviewed host, not UT1.'),
  dict(host='elementvape.com',category='shopping',url='https://www.elementvape.com/',reason='Substantial consumer retail purchases of vaping products; supplemental reviewed host.'),
 ])
 for n,r in enumerate(reviewed):
  put(r['host'],r['category']);d.execute('INSERT INTO evidence VALUES (?,?,?,?,?,?,?)',('review-'+str(n),r['host'],r['category'],r['url'],r['reason'],'2026-11-24T05:21:00Z',0))
 evidence=json.loads((ROOT/'evidence/cert-ut1-intersection.json').read_text());dl=json.loads((ROOT/'evidence/cert-download.json').read_text());fetched=datetime.datetime.fromisoformat(dl['fetched_at']).timestamp();expires=int(fetched+300)
 for r in evidence:
  host=r['DomainAddress'];put(host,'malware',expires)
  d.execute('INSERT INTO evidence VALUES (?,?,?,?,?,?,?)',('cert-'+str(r['RegisterPositionId']),host,'malware','https://hole.cert.pl/domains/v2/domains.json','Exact UT1 threat host corroborated in CERT Polska active phishing/warning list; not visited or executed',dl['fetched_at'],expires))
 meta=dict(policy='1.0',policy_hash=hashlib.sha256((ROOT/'docs/policy-v1.0.json').read_bytes()).hexdigest(),release='compact-ut1-reviewed-v1',ut1_sha256='69fcfadc1e24dccb61e2eb2458879f2a434db81ed0fda17ce050968af864c0cc',data_license='CC-BY-SA-4.0; UT1 attribution in LICENSE-NOTICES.md',scope='EXACT_HOST',enforcement='DISABLED',unknown_policy='UNDECIDED_UNRESOLVED_NOT_SAFE',threat_verified_at=dl['fetched_at'],threat_expires=str(expires),threat_source_sha256=dl['sha256'],provisional_source_mapping='Inherited 13-category source-label translations, not per-domain semantic audit')
 for k,v in meta.items():d.execute('INSERT INTO metadata VALUES (?,?)',(k,v))
 d.commit()
 all_evidence=[dict(zip(['id','host','category','source_url','reason','checked_at','expires'],row)) for row in d.execute('SELECT * FROM evidence')]
 (ROOT/'evidence/runtime-evidence.json').write_text(json.dumps(all_evidence,indent=2))
 # Runtime needs only a compact evidence reference; full supporting records stay separately preserved.
 d.execute('DROP TABLE evidence');d.execute('CREATE TABLE evidence(id TEXT PRIMARY KEY,source_url TEXT,checked_at TEXT) WITHOUT ROWID')
 d.execute('INSERT INTO evidence VALUES (?,?,?)',('review-ledger','evidence/runtime-evidence.json','2026-11-24'))
 d.execute('INSERT INTO metadata VALUES (?,?)',('category_counts',json.dumps({c:d.execute('SELECT count(*) FROM hosts WHERE mask & ? != 0',(BITS[c],)).fetchone()[0] for c in IDS})))
 d.commit();d.execute('VACUUM');d.execute('ANALYZE');d.commit()
 assert d.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 counts=[dict(category=c,count=d.execute('SELECT count(*) FROM hosts WHERE mask & ? != 0',(BITS[c],)).fetchone()[0]) for c in IDS];hosts=d.execute('SELECT count(*) FROM hosts').fetchone()[0];d.close();os.replace(tmp,target)
 manifest=dict(path=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),unique_hosts=hosts,counts=counts,metadata=meta,adult_reviewed=sum(1 for r in reviewed if r['category']=='adult'),threat_corroborated=len(evidence))
 (ROOT/'artifacts/runtime-manifest.json').write_text(json.dumps(manifest,indent=2));(ROOT/'evidence/reviewed-assignments.json').write_text(json.dumps(reviewed,indent=2));print(json.dumps(manifest,indent=2));return manifest
if __name__=='__main__':build()
