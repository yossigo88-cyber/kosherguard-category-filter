"""Compact, updateable, read-only reference runtime, no traffic or device adapters."""
from pathlib import Path
import sqlite3,json,hashlib,time,sys
from collections import OrderedDict
sys.path.insert(0,str(Path(__file__).parent))
from classifier import normalize,ReviewRequired,matches
ROOT=Path(__file__).resolve().parents[1]
POLICY=json.loads((ROOT/'docs/policy-v1.0.json').read_text())
IDS=[c['id'] for c in POLICY['categories']]
BITS={k:1<<i for i,k in enumerate(IDS)}

class Runtime:
 def __init__(self,path,corrections=None,cache=128):
  if not 0<=cache<=4096:raise ValueError('bounded cache required')
  self.path=Path(path);self.db=sqlite3.connect('file:'+str(self.path.resolve())+'?mode=ro',uri=True,check_same_thread=False);self.db.row_factory=sqlite3.Row
  self.db.execute('PRAGMA query_only=ON');self.db.execute('PRAGMA cache_size=-4096');self.db.execute('PRAGMA mmap_size=0')
  self.meta=dict(self.db.execute('SELECT key,value FROM metadata'));self.cache=OrderedDict();self.cap=cache
  if self.meta['policy_hash']!=hashlib.sha256((ROOT/'docs/policy-v1.0.json').read_bytes()).hexdigest():raise ReviewRequired('policy hash mismatch')
  from feed_validation import PSL
  self.psl=PSL(ROOT/'evidence/public_suffix_list.dat')
  self.corrections=corrections or [];self.cv=hashlib.sha256(json.dumps(self.corrections,sort_keys=True).encode()).hexdigest()
 def close(self):self.db.close()
 def classify(self,value,settings,selection_version='0',now=None):
  h=normalize(value);self.psl.validate(h);now=time.time() if now is None else now
  if set(settings)!=set(IDS) or any(type(v) is not bool for v in settings.values()):raise ReviewRequired('complete explicit boolean settings required, no silent legacy defaults')
  # Expiry participates in cache key. Expired threat evidence must not live in cache.
  key=(h,tuple(settings[k] for k in IDS),selection_version,self.cv,bool(now>=float(self.meta.get('threat_expires','0'))))
  if key in self.cache:return json.loads(self.cache[key])
  r=self.db.execute('SELECT mask,threat_expires FROM hosts WHERE host=?',(h,)).fetchone();mask=r['mask'] if r else 0;expired=False
  if mask&BITS['malware'] and r['threat_expires'] and now>=r['threat_expires']:mask&=~BITS['malware'];expired=True
  suppressed=[]
  revoked={c['supersedes'] for c in self.corrections if c.get('kind')=='REVOKE'}
  for c in self.corrections:
   if c.get('kind')=='REVOKE' or c['id'] in revoked:continue
   if c['category'] not in BITS:raise ReviewRequired('unknown correction category')
   if c.get('policy')!='1.0':raise ReviewRequired('correction policy mismatch')
   if matches(h,c['host'],c['scope']) and c['kind']=='SUPPRESS':
    mask&=~BITS[c['category']];suppressed.append(c['id'])
  cats=[c for c in IDS if mask&BITS[c]];blocking=[c for c in cats if settings[c]]
  status='MATCHED' if cats else ('SUPPRESSED' if suppressed else ('STALE_THREAT_EVIDENCE' if expired else 'UNKNOWN'))
  # NOT_SELECTED is a known category match, not a global assurance that the site is safe.
  decision='WOULD_BLOCK' if blocking else ('NO_SELECTED_CATEGORY_MATCH' if cats else 'UNRESOLVED')
  result=dict(host=h,status=status,categories=cats,blocking_categories=blocking,decision=decision,safe=False,traffic_action='NONE',enforcement=False,policy='1.0',release=self.meta['release'],selection_version=str(selection_version),correction_version=self.cv,suppressed=suppressed,evidence_expired=expired)
  if self.cap:
   self.cache[key]=json.dumps(result);self.cache.move_to_end(key)
   while len(self.cache)>self.cap:self.cache.popitem(last=False)
  return result
