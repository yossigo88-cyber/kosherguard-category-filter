from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
class PSL:
    def __init__(self,path=ROOT/'originals/public_suffix_list.dat'):
        data=Path(path).read_bytes();self.version='psl-sha256:'+hashlib.sha256(data).hexdigest()
        self.rules=set(); self.exceptions=set()
        for line in data.decode().splitlines():
            line=line.strip()
            if not line or line.startswith('//'):continue
            if line.startswith('!'):self.exceptions.add(self.ascii(line[1:]))
            else:self.rules.add(self.ascii(line))
    @staticmethod
    def ascii(s):return '.'.join(x.encode('idna').decode('ascii') if x!='*' else '*' for x in s.split('.'))
    def suffix(self,host):
        labels=host.split('.'); best=labels[-1]
        for i in range(len(labels)):
            tail='.'.join(labels[i:])
            if tail in self.exceptions:return '.'.join(labels[i+1:])
            if tail in self.rules:best=tail;break
            if i+1<len(labels) and '*.'+'.'.join(labels[i+1:]) in self.rules:best=tail;break
        return best
    def validate(self,host):
        if '.' not in host or self.suffix(host)==host:raise ValueError('public/private suffix or single-label host')

