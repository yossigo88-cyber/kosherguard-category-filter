Initial compact build used an incorrect SQL placeholder count; fixed before the first complete artifact. First 256 MiB concurrency benchmark could not create eight default-stack threads; set bounded 256 KiB stacks and MALLOC_ARENA_MAX=1 for the controlled benchmark, then reran successfully. This is a benchmark configuration, not a target-host guarantee.

UI checks found a wrapping brand/metric at 320px and missing charset in the static before-capture. Both corrected and screenshots rerendered. Original control markup rendered via static extraction is labeled as such, not a new live production screenshot.

All development runs are local loopback servers with synthetic settings. Test processes terminate servers/browsers on completion. Runtime API has no device, enrollment, profile, push, activation or traffic-routing APIs. Existing category HTML markers are preserved in the compatibility adapter; the new view and original-markup compatibility view share the same isolated settings state.
