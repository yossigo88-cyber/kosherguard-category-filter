# Data notices

UT1 database: Fabrice Prigent / Université Toulouse Capitole and supplied contributors. Source https://dsi.ut-capitole.fr/blacklists/ ; preserved archive https://dsi.ut-capitole.fr/blacklists/download/all.tar.gz . Original source archive SHA-256 69fcfadc1e24dccb61e2eb2458879f2a434db81ed0fda17ce050968af864c0cc. Creative Commons Attribution-ShareAlike 4.0 International: https://creativecommons.org/licenses/by-sa/4.0/ . Original license PDFs, warranty disclaimers and supplied contributor metadata retained alongside the evidence package. No endorsement is implied.

Changes: normalization/deduplication, conservative source-category mappings, explicit held/reviewed states, supplementary manual exact-host assignments, current third-party threat corroboration, compact bitmask SQLite compilation and expiry metadata. Adapted database and data exports remain CC BY-SA 4.0 with attribution, change notices and no extra downstream restrictions. No accuracy, completeness, fitness or maliciousness warranty is provided. The license is not a claim that unrelated dashboard software must use CC BY-SA.

CERT Polska / NASK-PIB Warning List: https://cert.pl/en/warning-list/ . Source policy permits use by any user for any purpose, including commercial, with no completeness, accuracy or maliciousness warranty. Attribution does not imply cooperation, partnership, endorsement, certification or support by NASK-PIB or CERT Polska. No names/logos used as endorsement. Verified active exact matches only, with five-minute runtime evidence expiry. Original source policy saved in evidence/cert-policy.txt. Entries can be withdrawn; do not permanently preserve a threat block simply because it appeared in a prior snapshot.

Public Suffix List: unmodified snapshot from https://publicsuffix.org/list/public_suffix_list.dat ; Mozilla Public License 2.0, original notices retained in evidence/public_suffix_list.dat. https://mozilla.org/MPL/2.0/ . Used for hostname boundaries, not as a categorization source.

Application code is separate from data licensing. Existing source ownership and license status are not changed by this notice.
