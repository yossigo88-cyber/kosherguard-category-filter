import unittest,sys,sqlite3,tempfile,json,copy,hashlib,time,threading,urllib.request,urllib.error,resource
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from runtime import Runtime,IDS,BITS,ReviewRequired
from server import State,App,handler,ThreadingHTTPServer
from update import install

class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.p=Path(cls.tmp.name);cls.fixture=cls.p/'fixture.sqlite'
  s=sqlite3.connect(ROOT/'artifacts/runtime.sqlite');d=sqlite3.connect(cls.fixture);s.backup(d);s.close()
  for i,c in enumerate(IDS):d.execute('INSERT INTO hosts VALUES (?,?,0)',(c+'.test',BITS[c]))
  d.execute('INSERT INTO hosts VALUES (?,?,0)',('multi.test',BITS['adult']|BITS['social']));d.commit();d.close()
  cls.runtime=Runtime(cls.fixture)
 @classmethod
 def tearDownClass(cls):cls.runtime.close();cls.tmp.cleanup()
 def settings(self):return {c:False for c in IDS}
 def test_all_28_on_off(self):
  for c in IDS:
   with self.subTest(c=c):
    s=self.settings();self.assertEqual(self.runtime.classify(c+'.test',s)['decision'],'NO_SELECTED_CATEGORY_MATCH');s[c]=True;self.assertEqual(self.runtime.classify(c+'.test',s)['blocking_categories'],[c]);s[c]=False;self.assertEqual(self.runtime.classify(c+'.test',s)['blocking_categories'],[])
 def test_multi_category_any_enabled(self):
  s=self.settings();s['social']=True;self.assertEqual(self.runtime.classify('multi.test',s)['blocking_categories'],['social']);s['adult']=True;self.assertEqual(set(self.runtime.classify('multi.test',s)['blocking_categories']),{'adult','social'})
 def test_unknown_never_safe(self):
  r=self.runtime.classify('unknown.invalid',self.settings());self.assertEqual(r['decision'],'UNRESOLVED');self.assertFalse(r['safe']);self.assertEqual(r['traffic_action'],'NONE')
 def test_known_off_not_safe(self):self.assertFalse(self.runtime.classify('adult.test',self.settings())['safe'])
 def test_missing_legacy_no_default(self):
  with self.assertRaises(ReviewRequired):self.runtime.classify('adult.test',{})
 def test_exact_not_descendant(self):self.assertEqual(self.runtime.classify('child.adult.test',self.settings())['status'],'UNKNOWN')
 def test_boundary(self):self.assertEqual(self.runtime.classify('notadult.test',self.settings())['status'],'UNKNOWN')
 def test_bad_input(self):
  for h in ['https://x.com/','x.com:443','*.x.com','127.0.0.1','com','github.io','a..com']:
   with self.subTest(h=h),self.assertRaises(ValueError):self.runtime.classify(h,self.settings())
 def test_suppression_same_category(self):
  cs=[dict(id='a',kind='SUPPRESS',host='multi.test',scope='EXACT_HOST',category='adult',policy='1.0')];r=Runtime(self.fixture,cs)
  x=r.classify('multi.test',{k:True for k in IDS});self.assertEqual(x['categories'],['social']);r.close()
 def test_correction_policy(self):
  r=Runtime(self.fixture,[dict(id='bad',kind='SUPPRESS',host='multi.test',scope='EXACT_HOST',category='adult',policy='2.0')])
  with self.assertRaises(ReviewRequired):r.classify('multi.test',self.settings())
  r.close()
 def test_cache_bound_and_settings(self):
  for i in range(200):self.runtime.classify('n'+str(i)+'.invalid',self.settings())
  self.assertLessEqual(len(self.runtime.cache),128)
  s=self.settings();self.runtime.classify('adult.test',s);s['adult']=True;self.assertEqual(self.runtime.classify('adult.test',s)['decision'],'WOULD_BLOCK')
 def test_readonly(self):
  with self.assertRaises(sqlite3.OperationalError):self.runtime.db.execute('DELETE FROM hosts')
 def test_no_enforcement(self):self.assertFalse(self.runtime.classify('adult.test',{k:True for k in IDS})['enforcement'])
 def test_threat_expiry(self):
  h=self.runtime.db.execute('SELECT host,threat_expires FROM hosts WHERE threat_expires>0 LIMIT 1').fetchone();s={k:True for k in IDS};before=self.runtime.classify(h['host'],s,now=h['threat_expires']-1);after=self.runtime.classify(h['host'],s,now=h['threat_expires']);self.assertIn('malware',before['categories']);self.assertNotIn('malware',after['categories']);self.assertFalse(after['safe']);self.assertEqual(after['decision'],'UNRESOLVED')
 def test_sensitive_exclusion_regressions(self):
  # Exact source-list overlap exclusions and supported explicit category. Not a claim of internet-wide specificity.
  for h in ['bishuk.com','kinseyconfidential.org','masexualite.ca','handentspannung.de','plannedparenthood.org','wikipedia.org']:
   self.assertNotIn('adult',self.runtime.classify(h,self.settings())['categories'])
  self.assertIn('adult',self.runtime.classify('pornhub.com',self.settings())['categories'])
 def test_state_existing_preserved(self):
  path=self.p/'state.json';s=State(path);x=s.read();x['settings']['adult']=True;x['unknown_field']='keep';x['metadata']['device_fixture']='synthetic only';s.write(x);s.update('gaming',True);y=s.read();self.assertTrue(y['settings']['adult']);self.assertEqual(y['unknown_field'],'keep');self.assertEqual(y['metadata'],x['metadata'])
 def test_partial_existing_blocks_write(self):
  s=State(self.p/'partial.json');x=s.read();del x['settings']['adult'];s.write(x);before=s.path.read_bytes()
  with self.assertRaises(ReviewRequired):s.update('gaming',True)
  self.assertEqual(s.path.read_bytes(),before)
 def test_atomic_update_preserves_corrections(self):
  s=State(self.p/'update-state.json');s.correct('multi.test','adult');s.update('social',True);before=s.path.read_bytes();target=self.p/'target.sqlite';sha=hashlib.sha256(self.fixture.read_bytes()).hexdigest();r=install(self.fixture,target,s.path,sha);self.assertTrue(r['state_unchanged']);self.assertEqual(s.path.read_bytes(),before)
  with self.assertRaises(ValueError):install(self.fixture,target,s.path,'wrong')
 def test_28_policy_fidelity(self):
  p=json.loads((ROOT/'docs/policy-v1.0.json').read_text())
  for c in p['categories']:
   r=self.runtime.db.execute('SELECT definition,inclusions,exclusions,rules FROM categories WHERE id=?',(c['id'],)).fetchone();self.assertEqual(tuple(r),tuple(c[k] for k in ['definition','yes','no','rules']))
 def test_offline_migration_preserves_all_flags_and_corrections(self):
  from migrate import migrate_record
  record={'siteCategorySettings':{c:i%2==0 for i,c in enumerate(IDS)},'corrections':[dict(id='saved',host='multi.test',category='adult',kind='SUPPRESS',scope='EXACT_HOST',policy='1.0')],'unrelated':{'untouched':True}}
  before=copy.deepcopy(record);out=migrate_record(record,self.p/'migrated.json');self.assertEqual(out['settings'],record['siteCategorySettings']);self.assertEqual(out['corrections'],record['corrections']);self.assertEqual(record,before)
 def test_runtime_rebuild_deterministic_data(self):
  self.assertEqual(self.runtime.meta['policy'],'1.0');self.assertEqual(len(self.runtime.db.execute('SELECT * FROM categories').fetchall()),28)
 def test_correction_revoke_append_only(self):
  state=State(self.p/'revoke.json');c=state.correct('multi.test','adult');state.revoke(c['id']);r=Runtime(self.fixture,state.read()['corrections']);self.assertIn('adult',r.classify('multi.test',self.settings())['categories']);r.close();self.assertEqual(len(state.read()['corrections']),2)
 def test_stale_selection_conflict(self):
  state=State(self.p/'conflict.json');state.update('adult',True,0)
  with self.assertRaises(ReviewRequired):state.update('gaming',True,0)
  self.assertFalse(state.read()['settings']['gaming']);self.assertTrue(state.read()['settings']['adult'])
 def test_http_end_to_end_and_forbidden_routes(self):
  app=App(self.fixture,self.p/'http-state.json');srv=ThreadingHTTPServer(('127.0.0.1',0),handler(app));thread=threading.Thread(target=srv.serve_forever,daemon=True);thread.start();base='http://127.0.0.1:'+str(srv.server_port)
  def post(path,data):
   req=urllib.request.Request(base+path,data=json.dumps(data).encode(),headers={'Content-Type':'application/json'});return json.load(urllib.request.urlopen(req))
  try:
   for c in IDS:
    post('/api/category-filter/settings',dict(category=c,blocked=True));r=post('/api/category-filter/classify',dict(host=c+'.test'));self.assertIn(c,r['blocking_categories']);post('/api/category-filter/settings',dict(category=c,blocked=False));r=post('/api/category-filter/classify',dict(host=c+'.test'));self.assertEqual(r['blocking_categories'],[])
   for path in ['/api/device/x/enqueue','/api/enroll','/api/activate','/api/device/x/site-category-settings']:
    with self.assertRaises(urllib.error.HTTPError) as e:post(path,{})
    self.assertEqual(e.exception.code,404)
  finally:srv.shutdown();srv.server_close();thread.join()
if __name__=='__main__':unittest.main(verbosity=2)
