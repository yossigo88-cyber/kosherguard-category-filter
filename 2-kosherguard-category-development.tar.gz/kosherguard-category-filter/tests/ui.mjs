import {fileURLToPath} from 'node:url';import {dirname,resolve} from 'node:path';
import {findChrome,launchChrome} from './chrome.mjs';
import {spawn} from 'node:child_process';import {mkdtempSync,readFileSync,writeFileSync,rmSync} from 'node:fs';import assert from 'node:assert/strict';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');const dir=mkdtempSync('/tmp/kg-ui-');const server=spawn('python',[root+'/src/server.py'],{env:{...process.env,PORT:'8766',STAGING_STATE:dir+'/state.json'},stdio:['ignore','pipe','pipe']});const chrome=await launchChrome(findChrome(),dir+'/chrome');const shots=[];
try{
 for(let i=0;i<80;i++){try{await fetch('http://127.0.0.1:8766/health');break}catch{await new Promise(r=>setTimeout(r,50))}}
 const {page}=await chrome.cdp.openPage();await page('Runtime.enable');await page('Page.enable');
 const js=async expression=>{const r=await page('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value};
 async function ready(){for(let i=0;i<100;i++){if(await js('document.querySelectorAll("[role=switch]").length===28'))return;await new Promise(r=>setTimeout(r,30))}throw Error('dashboard not ready')}
 await page('Page.navigate',{url:'http://127.0.0.1:8766/'});await ready();
 const coverage=await js('[...document.querySelectorAll(".coverage")].map(x=>x.textContent)');assert.equal(coverage.length,28);assert.equal(coverage.filter(x=>x.includes('empty coverage')).length,5);assert.equal(coverage.filter(x=>x.includes('limited coverage')).length,22);assert.equal(coverage.filter(x=>x.includes('expired, unresolved')).length,1);
 const counts=await js('state.categories.map(c=>({id:c.id,count:c.count,shown:document.querySelector(`[data-category="${c.id}"] .coverage`).textContent}))');for(const c of counts)assert.ok(c.shown.includes(c.count.toLocaleString()));
 const ids=await js('[...document.querySelectorAll("[role=switch]")].map(x=>x.dataset.siteCategory)');assert.equal(ids.length,28);
 // Actual DOM click path, not direct change-event invocation.
 for(const id of ids){
  await js(`document.querySelector('[data-site-category="${id}"]').click()`);
  for(let i=0;i<100;i++){if(await js(`!busy&&state.settings['${id}']===true`))break;await new Promise(r=>setTimeout(r,15))}
  assert.equal(await js(`state.settings['${id}']`),true);
  await js(`document.querySelector('[data-site-category="${id}"]').click()`);
  for(let i=0;i<100;i++){if(await js(`!busy&&state.settings['${id}']===false`))break;await new Promise(r=>setTimeout(r,15))}
  assert.equal(await js(`state.settings['${id}']`),false);
 }
 const before=await js('JSON.stringify(state.settings)');await js('document.querySelector(".category-copy").click()');assert.equal(await js('JSON.stringify(state.settings)'),before);
 await js(`document.querySelector('[data-site-category="adult"]').click()`);for(let i=0;i<100;i++){if(await js('!busy&&state.settings.adult'))break;await new Promise(r=>setTimeout(r,15))}
 await page('Page.navigate',{url:'http://127.0.0.1:8766/'});await ready();assert.equal(await js('state.settings.adult'),true);
 await js(`document.querySelector('#host').value='pornhub.com';document.querySelector('#lookup-form').requestSubmit()`);for(let i=0;i<100;i++){if((await js('document.querySelector("#lookup-result").textContent')).includes('Would block'))break;await new Promise(r=>setTimeout(r,20))}assert.ok((await js('document.querySelector("#lookup-result").textContent')).includes('Would block'));
 await js(`document.querySelector('#host').value='unknown.invalid';document.querySelector('#lookup-form').requestSubmit()`);for(let i=0;i<100;i++){if((await js('document.querySelector("#lookup-result").textContent')).includes('Unresolved'))break;await new Promise(r=>setTimeout(r,20))}assert.ok((await js('document.querySelector("#lookup-result").textContent')).includes('Unresolved'));
 // Existing dashboard category markup, using shared persisted setting adapter.
 await page('Page.navigate',{url:'http://127.0.0.1:8766/categories'});
 for(let i=0;i<100;i++){if(await js('document.body.dataset.ready==="true"'))break;await new Promise(r=>setTimeout(r,20))}
 assert.equal(await js('document.querySelectorAll("[data-site-category]").length'),28);
 assert.equal(await js('document.querySelector("[data-site-category=adult]").checked'),true);
 await js('document.querySelector("[data-site-category=gaming]").click()');
 for(let i=0;i<100;i++){if(await js('!document.querySelector("[data-site-category=gaming]").disabled'))break;await new Promise(r=>setTimeout(r,20))}
 assert.equal(await js('document.querySelector("[data-site-category=gaming]").checked'),true);
 await page('Page.navigate',{url:'http://127.0.0.1:8766/'});await ready();assert.equal(await js('state.settings.gaming'),true);
 for(const width of [320,390,1280]){
  await page('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:false});
  await js('document.querySelector("[data-group=all]").click()');
  assert.ok(await js('document.documentElement.scrollWidth<=innerWidth'));
  const height=await js('document.documentElement.scrollHeight');
  for(let y=0,i=0;y<height;y+=1400,i++){
   const out=`${dir}/kg-category-after-${width}-${i}.png`;const r=await page('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y,width,height:Math.min(1400,height-y),scale:1}});writeFileSync(out,Buffer.from(r.data,'base64'));shots.push(out)
  }
 }
 await page('Page.navigate',{url:'http://127.0.0.1:8766/before'});await page('Emulation.setDeviceMetricsOverride',{width:390,height:1000,deviceScaleFactor:1,mobile:false});await new Promise(r=>setTimeout(r,100));const r=await page('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:390,height:1400,scale:1}});writeFileSync(`${dir}/kg-category-before.png`,Buffer.from(r.data,'base64'));
 writeFileSync(root+'/artifacts/ui-tests.json',JSON.stringify({passed:true,actual_switch_on_off_clicks:56,existing_dashboard_adapter:true,coverage_counts_match:true,empty_states:5,limited_states:22,expired_threat_state:true,all_28_persisted:true,label_inert:true,refresh_preserved:true,lookup_block:true,unknown_unresolved:true,widths:[320,390,1280],screenshots:shots},null,2));console.log('PASS',shots.length,'screenshots; 56 real DOM switch clicks, persistence, lookup, unknown and responsive overflow checks');
}finally{await chrome.kill();server.kill();await new Promise(r=>server.once('exit',r));rmSync(dir,{recursive:true,force:true})}
