// Optional portable UI-test adapter. Install puppeteer in your own development environment.
import puppeteer from 'puppeteer';
export function findChrome(){return process.env.CHROME_BIN||process.env.PUPPETEER_EXECUTABLE_PATH||undefined}
export async function launchChrome(executablePath,userDataDir){
 const browser=await puppeteer.launch({headless:true,executablePath,userDataDir,args:['--no-sandbox']});
 return {cdp:{async openPage(){const tab=await browser.newPage();const session=await tab.createCDPSession();return {page:(method,params={})=>session.send(method,params)}}},kill:()=>browser.close()};
}
