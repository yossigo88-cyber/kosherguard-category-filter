import sys,time,json,resource,statistics,concurrent.futures,sqlite3,threading
threading.stack_size(262144)
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from runtime import Runtime,ROOT,IDS
r=Runtime(ROOT/'artifacts/runtime.sqlite');hosts=[x[0] for x in r.db.execute('SELECT host FROM hosts ORDER BY host LIMIT 2000')]+['absent-'+str(i)+'.invalid' for i in range(2000)];s={k:True for k in IDS};ts=[]
for h in hosts:
 t=time.perf_counter_ns();r.classify(h,s);ts.append((time.perf_counter_ns()-t)/1e6)
ts.sort();r.close()
def batch(index):
 rr=Runtime(ROOT/'artifacts/runtime.sqlite');start=time.perf_counter()
 for h in hosts[index*250:(index+1)*250]:rr.classify(h,s)
 rr.close();return time.perf_counter()-start
start=time.perf_counter()
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as e:times=list(e.map(batch,range(8)))
parallel=time.perf_counter()-start
out=dict(queries=len(ts),p50_ms=statistics.median(ts),p95_ms=ts[int(len(ts)*.95)],p99_ms=ts[int(len(ts)*.99)],max_ms=max(ts),peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,database_bytes=(ROOT/'artifacts/runtime.sqlite').stat().st_size,concurrent_workers=8,concurrent_queries=2000,concurrent_seconds=parallel,concurrent_queries_per_second=2000/parallel,caveat='Local 256 MiB virtual-memory cap, warm OS cache, one process, not target host baseline or internet traffic distribution. Includes eight independent read-only SQLite connections; no packet filtering, production or settings access.')
(ROOT/'artifacts/performance.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
