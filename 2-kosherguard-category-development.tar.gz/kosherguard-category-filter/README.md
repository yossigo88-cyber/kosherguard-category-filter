Accepted coverage scope, 24 Nov 2026 00:39 ET: limited or empty categories are acceptable; accuracy takes priority. This is a tested staging category-decision implementation, not a production traffic filter. Every category shows a numeric count and explicit limited/empty state. Expired threats show zero current hosts plus stored count.

# KosherGuard website category filter, development handoff

24 Nov 2026. No deployment. Production filtering disabled. This package implements a compact lookup runtime, a category-only HTTP adapter and polished dashboard, plus an adapter for the existing dashboard's exact `data-site-category` controls. It is NOT a complete-coverage internet categorization service, a live network filter, or a production-ready deployment.

## Run the isolated development result

Extract this code archive, then place the separately supplied `kosherguard-category-runtime.sqlite` at `artifacts/runtime.sqlite` inside the extracted project directory.

Python 3.10+ and `idna` are required. No paid service or dependency install was performed. This development environment already has idna 3.3. From the project directory:

```
python src/server.py
```

Open `http://127.0.0.1:8766/`. This is a local address after starting the project, not a hosted preview link. `/categories` exercises the existing dashboard category markup with the shared adapter. The server binds loopback only, has no device or MDM routes and performs no network calls. Settings live only in `artifacts/staging-settings.json`, created for a new staging configuration with all 28 flags explicitly OFF. Never point this development server at live settings. Existing partial records are rejected rather than silently reset.

```
python -m unittest discover -s tests -v
(ulimit -v 262144; MALLOC_ARENA_MAX=1 python tests/benchmark.py)
node tests/ui.mjs
```

The browser test requires Node, Chrome and the optional free puppeteer package. Its portable adapter is supplied in tests/chrome.mjs. This optional adapter was syntax-checked, not rerun with Puppeteer in the handoff environment; the UI results were obtained using the original local Chrome runner. The actual local UI test results are in artifacts/ui-tests.json. No dependency installation is needed to read those results. The application itself has no Node or browser-test dependency. Historical screenshot paths in the results refer to the original test run; representative screenshots are supplied separately.

## Actual deliverables

- `artifacts/runtime.sqlite`: compact real-data runtime, exact host bitmasks, all 28 frozen definitions, release and provenance hashes. About 8 MiB, not the 4.50 GiB evidence store.
- `src/runtime.py`: strict normalization, indexed exact-host lookup, bounded cache and SQLite cache; expired threats and unknowns are unresolved, never safe. Any enabled matched category yields WOULD_BLOCK; an OFF flag cannot override another ON flag. All results have `enforcement=false`, `traffic_action=NONE`, `safe=false`.
- `src/server.py`, `public/`: category-only staging dashboard and API. Both the redesigned UI and original-control adapter use the same saved state. No enrollment, device, profile, push, or activation code.
- `src/update.py`: offline checksum/integrity/policy-checked atomic runtime replacement, previous artifact backup, correction/settings state unchanged. Corrections are separate from feeds, append-only suppression/revocation records; fresh feeds cannot auto-resurrect a suppressed category.
- `src/migrate.py`: offline migration from an explicitly supplied existing category record, preserving all 28 flags, corrections and unrelated fields. No live device records accessed.
- `src/build_runtime.py`, `src/refresh_threat.py`: explicit build and one-shot evidence-refresh helpers. No polling, scheduler or service was started. Set `KOSHERGUARD_STAGING_SOURCE` to the retained full staging directory when rebuilding. Original full archive and full staging data are not part of this small runtime package.
- `artifacts/tests-final.txt`, `ui-tests.json`, `performance.json`: test and measured resource results.
- `evidence/`: separately retained review ledger and source pages. It is not needed for each runtime lookup but is needed for auditable future updates. Full UT1 evidence remains in the original retained staging package.

## Evidence and coverage limits

All 28 switches and policy definitions are implemented and tested with category fixtures. This is not evidence of comprehensive real coverage for all 28 categories.

The inherited 13-category mapping is a provisional UT1 source-label translation, not a per-host semantic audit. One Adult hostname, pornhub.com, was added after non-graphic first-party platform documentation describing sexually explicit content and UT1 membership. All other broad Adult entries remain uncertain, including the health/sexual-education overlap exclusions. No keyword-based or ordinary-nudity classification.

105,894 UT1 threat hostnames were corroborated by exact membership in CERT Polska's active Warning List fetched 24 Nov 2026 at 05:19:16 UTC. This is credible third-party indicator evidence, not forensic payload proof. No listed malicious host was visited. The source recommends five-minute refreshes, so runtime labels expire five minutes after the verified fetch; by handoff they are stale and resolve as STALE_THREAT_EVIDENCE/UNRESOLVED, not safe or permanently malicious. An explicitly run evidence refresh and replacement build is required before current threat labels are usable. No automatic refresh was activated. An empty/invalid response does not wipe a working runtime.

Reviewed supplementary exact hosts cover a few narrow gaps: ome.tv for random video chat/messaging/social, elementvape.com for vaping/shop. These are clearly labeled supplemental, not misrepresented as UT1 entries. Reviewed UT1 hosts include torproject.org for browser/bypass, bittorrent.com for the expressly included torrent-client policy, chatgpt.com for AI, dropbox.com for cloud storage, youtube.com for prerecorded video. No whole-provider inference or descendant inheritance.

Still unsupported with zero real runtime assignments: Mixed, Self-harm, Hacking & cheating, Web mail and Ads & trackers. Several other categories have only one reviewed hostname. Marking one example is not finishing category coverage. Large ambiguous UT1 buckets stay in the original review queue. No web-scale Adult audit, clinical harm-content audit, precision/recall truth set or global false-positive rate is claimed. This is an unresolved data-quality requirement, not a routine implementation choice to hide.

## Tests and resource measurements

- 24 development tests pass, covering all 28 fixture categories ON/OFF, many-to-many behavior, exact boundaries, invalid input, read-only runtime, bounded cache, unknown never safe, stale threats, specific sexual-health exclusions, corrections/revocation, migration, optimistic settings conflicts, atomic update and HTTP end-to-end behavior.
- Browser run: 56 actual DOM switch clicks for 28 ON/OFF controls, label-body inertness, saved-state refresh, real Adult lookup, unknown result, existing-control adapter, no horizontal overflow at 320/390/1280. Synthetic settings only.
- Existing earlier suites remain separately retained: 36 Checkpoint A tests and 50 full-staging tests passed. They were not merged into a misleading new aggregate count.
- Local benchmark: 4,000 lookups and 2,000 lookups across eight read-only connections under a 256 MiB virtual-memory cap. Exact values in performance.json. Warm OS cache, synthetic all-ON flags, one process, not representative internet traffic or a target-server certification. OS page cache is not all included in process RSS.
- The 8 MiB runtime and measured process memory are within a 1 GiB envelope locally. No conclusion about spare memory or other services on the real 1GB server is possible without a fresh deployment baseline. No server access was made.

## What remains before real use

1. Finish semantic data review and credible sources for missing/held categories, especially Adult. Do not call the current data complete.
2. Choose unknown/outage traffic behavior. This package deliberately makes no allow/block choice for unresolved or unavailable results.
3. Choose and test a supported traffic-enforcement integration. A dashboard decision engine does not itself intercept DNS, browsers, HTTPS or phone traffic. None is deployed or activated.
4. Production authentication/authorization, TLS/reverse-proxy configuration, rate limits, bounded worker concurrency, live-state export/migration, current source-refresh operations and rollback rehearsal need a separately approved deployment plan.
5. Rebaseline RAM, disk and concurrent load with existing services on the target server. Retain full provenance elsewhere, not in the runtime hot path.

No live website, production DB, app, MDM, enrollment, customer device or phone settings changed. Existing live selections and corrections are preserved by non-access; migration preservation is proven on fixtures, not claimed as a live migration. No purchase, subscription, deployment, hosted backend or filtering activation.
